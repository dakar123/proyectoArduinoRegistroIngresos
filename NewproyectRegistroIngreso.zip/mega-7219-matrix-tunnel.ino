#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Keypad.h>
#include <MD_Parola.h>
#include <MD_MAX72xx.h>
#include <SPI.h>

// --- CONFIGURACIÓN PANTALLA OLED ---
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// --- CONFIGURACIÓN MATRIZ LED ---
#define HARDWARE_TYPE MD_MAX72XX::PAROLA_HW
#define MAX_DEVICES 8 // 64 columnas = 8 modulos de 8x8
#define CS_PIN 53
#define DATA_PIN 51
#define CLK_PIN 52
MD_Parola panel = MD_Parola(HARDWARE_TYPE, DATA_PIN, CLK_PIN, CS_PIN, MAX_DEVICES);

// --- CONFIGURACIÓN TECLADO MATRICIAL ---
const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {22, 24, 26, 28};
byte colPins[COLS] = {30, 32, 34, 36};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// --- CONFIGURACIÓN DE PINES ---
#define PIR_PIN 2
#define BUZZER_PIN 3
#define LED_DENIED 4
#define LED_GRANTED 5
#define LED_ALARM 6 // led4 extra

// Array de los 15 LEDs que simulan la puerta
const int doorLeds[15] = {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, A0, A1, A2};

// --- VARIABLES DE LÓGICA ---
String password_correcta = "1234";
String input_password = "";
int intentos = 0;
bool sistema_activo = false;

void setup() {
  Serial.begin(9600);
  
  // Iniciar pines
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_DENIED, OUTPUT);
  pinMode(LED_GRANTED, OUTPUT);
  pinMode(LED_ALARM, OUTPUT);

  // Iniciar puerta cerrada (Todos los LEDs encendidos)
  for(int i = 0; i < 15; i++){
    pinMode(doorLeds[i], OUTPUT);
    digitalWrite(doorLeds[i], HIGH); 
  }

  // Iniciar OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3D)) { // Dirección 0x3D para tu OLED
    Serial.println(F("OLED fallo"));
    for(;;);
  }
  display.clearDisplay();
  
  // Iniciar Matriz
  panel.begin();
  panel.setIntensity(5);
  panel.displayClear();

  estadoReposo();
}

void loop() {
  if (!sistema_activo) {
    // Esperar a que el PIR detecte movimiento
    if (digitalRead(PIR_PIN) == HIGH) {
      activarSistema();
    }
  } else {
    // Sistema activo: leer teclado
    char key = keypad.getKey();
    
    if (key) {
      tone(BUZZER_PIN, 1000, 50); // Sonido de tecla
      
      if (key == '*' || key == '#') {
        input_password = ""; // Resetear si se presiona * o #
        actualizarOLEDClave();
      } 
      else {
        input_password += key;
        actualizarOLEDClave();
        
        if (input_password.length() == password_correcta.length()) {
          verificarClave();
        }
      }
    }
  }
}

// --- FUNCIONES MODULARES ---

void estadoReposo() {
  sistema_activo = false;
  input_password = "";
  intentos = 0;
  
  digitalWrite(LED_GRANTED, LOW);
  digitalWrite(LED_DENIED, LOW);
  digitalWrite(LED_ALARM, LOW);
  
  // Asegurar puerta cerrada
  for(int i=0; i<15; i++) digitalWrite(doorLeds[i], HIGH);

  panel.displayClear();
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(10, 25);
  display.println("Sistema Bloqueado");
  display.display();
}

void activarSistema() {
  sistema_activo = true;
  input_password = "";
  
  panel.print("BIENVENIDO");
  
  actualizarOLEDClave();
}

void actualizarOLEDClave() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Intentos rest: ");
  display.println(3 - intentos);
  
  display.setTextSize(2);
  display.setCursor(10, 25);
  display.print("PIN: ");
  // Mostrar asteriscos para ocultar la clave
  for(int i=0; i<input_password.length(); i++){
    display.print("*");
  }
  display.display();
}

void verificarClave() {
  if (input_password == password_correcta) {
    accesoConcedido();
  } else {
    accesoDenegado();
  }
  input_password = ""; // Limpiar para el siguiente intento
}

void accesoConcedido() {
  digitalWrite(LED_GRANTED, HIGH);
  digitalWrite(LED_DENIED, LOW);
  
  panel.print("PASA");
  
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(10, 20);
  display.println("ACCESO");
  display.setCursor(10, 40);
  display.println("PERMITIDO");
  display.display();

  tone(BUZZER_PIN, 2000, 500); // Tono de éxito

  animacionAbrirPuerta();
  
  delay(4000); // Tiempo con la puerta abierta
  
  animacionCerrarPuerta();
  estadoReposo();
}

void accesoDenegado() {
  intentos++;
  digitalWrite(LED_DENIED, HIGH);
  
  panel.print("ERROR");
  
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(10, 25);
  display.println("INCORRECTO");
  display.display();

  tone(BUZZER_PIN, 500, 1000); // Tono de error
  delay(1500);
  digitalWrite(LED_DENIED, LOW);

  if (intentos >= 3) {
    activarAlarma();
  } else {
    panel.print("BIENVENIDO");
    actualizarOLEDClave();
  }
}

void activarAlarma() {
  panel.print("BLOQUEADO");
  
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(10, 25);
  display.println("ALARMA!");
  display.display();

  // Parpadear LED rojo y sonar alarma por 5 segundos
  for (int i = 0; i < 10; i++) {
    digitalWrite(LED_DENIED, HIGH);
    digitalWrite(LED_ALARM, HIGH);
    tone(BUZZER_PIN, 1500);
    delay(250);
    digitalWrite(LED_DENIED, LOW);
    digitalWrite(LED_ALARM, LOW);
    noTone(BUZZER_PIN);
    delay(250);
  }
  
  estadoReposo();
}

// --- ANIMACIONES DE LA PUERTA (15 LEDs) ---
void animacionAbrirPuerta() {
  // Apagar desde el centro (índice 7) hacia los lados (0 y 14)
  int centro = 7;
  digitalWrite(doorLeds[centro], LOW);
  delay(150);
  
  for(int i = 1; i <= 7; i++) {
    digitalWrite(doorLeds[centro - i], LOW);
    digitalWrite(doorLeds[centro + i], LOW);
    delay(150);
  }
}

void animacionCerrarPuerta() {
  // Encender desde los lados hacia el centro
  int centro = 7;
  for(int i = 7; i >= 1; i--) {
    digitalWrite(doorLeds[centro - i], HIGH);
    digitalWrite(doorLeds[centro + i], HIGH);
    delay(150);
  }
  digitalWrite(doorLeds[centro], HIGH);
  delay(150);
}